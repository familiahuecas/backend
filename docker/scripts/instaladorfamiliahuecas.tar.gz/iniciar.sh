#!/bin/bash

echo "==========Starting Docker Compose================================"
docker compose -f ./conf/docker-compose.yml up -d

