#!/bin/bash

echo "==========Stopping Docker Compose================================"
docker-compose -f ./conf/docker-compose.yml down

